# Figure2_composite_SROC.R  ->  manuscript Figure 2 (vector PDF + 300 dpi PNG)
# Inputs (same folder): diagmeta_results_adult.xlsx, diagmeta_results_PED.xlsx,
#   diagmeta_results_BEC.xlsx, MasterDataV2.xlsx, DIVE_Analysis.xlsx
# Run: setwd() to this folder, then source("Figure2_composite_SROC.R")

suppressPackageStartupMessages({
  library(readxl); library(ggplot2); library(dplyr); library(patchwork)
  library(grid);   library(mada);    library(pROC)
})

F_ADULT <- "diagmeta_results_adult.xlsx"
F_PED   <- "diagmeta_results_PED.xlsx"
F_BEC   <- "diagmeta_results_BEC.xlsx"
F_BIVAR <- "MasterDataV2.xlsx"
F_DIVE  <- "DIVE_Analysis.xlsx"

C_FENO <- "#1B9E77"; C_BEC <- "#D95F02"; C_COMBO <- "#7570B3"

title_theme <- function() theme(
  plot.title=element_text(hjust=0.5, face="bold", size=10.5, colour="black", margin=margin(b=2)))

sroc_theme <- function(tag, ratio = 1) list(
  scale_x_continuous(limits=c(0,1), expand=c(0.01,0.01), breaks=seq(0,1,0.25), minor_breaks=seq(0,1,0.05)),
  scale_y_continuous(limits=c(0,1), expand=c(0.01,0.01), breaks=seq(0,1,0.25), minor_breaks=seq(0,1,0.05)),
  coord_fixed(ratio = ratio),
  labs(x="1 - Specificity", y="Sensitivity", tag=tag),
  theme_classic(base_size=11),
  theme(plot.tag=element_text(face="bold", size=13),
        axis.title=element_text(size=10, face="bold", colour="grey20"),
        axis.text=element_text(size=9, colour="grey30"),
        axis.ticks=element_line(colour="grey50", linewidth=0.4),
        axis.ticks.length=unit(0.12,"cm"),
        axis.line=element_line(colour="grey30", linewidth=0.5),
        plot.margin=margin(2,6,2,6)),
  guides(x=guide_axis(minor.ticks=TRUE), y=guide_axis(minor.ticks=TRUE)))

auc_legend_theme <- function(txt=10) theme(
  legend.position=c(0.98,0.03), legend.justification=c(1,0), legend.title=element_blank(),
  legend.text=element_text(size=txt, colour="black"), legend.key.height=unit(0.9,"lines"), legend.key.width=unit(1.5,"lines"),
  legend.background=element_rect(fill=alpha("white",0.75), colour=NA), legend.key=element_rect(fill=NA, colour=NA))

auc_lab <- function(name, file, sub) {
  s <- read_excel(file, sheet="Summary"); r <- s[s$Subgroup==sub, ]
  sprintf("%s (AUC = %.2f [%.2f; %.2f])", name, r$AUC[1], r$AUC_Lower[1], r$AUC_Upper[1])
}

## Panel A - FeNO + BEC adults SROC overlay
panelA <- function() {
  fa <- read_excel(F_ADULT, sheet="BPT_PC20<8"); fa$FPR <- 1 - fa$Spec
  fb <- read_excel(F_BEC,   sheet="PC20<8");     fb$FPR <- 1 - fb$Spec
  df <- rbind(
    data.frame(FPR=fa$FPR, Sens=fa$Sens, lo=fa$`lower.Sens`, up=fa$`upper.Sens`, m="FeNO"),
    data.frame(FPR=fb$FPR, Sens=fb$Sens, lo=fb$`lower.Sens`, up=fb$`upper.Sens`, m="BEC"))
  df <- df[order(df$m, df$FPR), ]; df$m <- factor(df$m, levels=c("FeNO","BEC"))
  labs2 <- c(auc_lab("FeNO", F_ADULT, "BPT_PC20<8"), auc_lab("BEC", F_BEC, "PC20<8"))
  ggplot(df, aes(FPR, Sens, colour=m, fill=m)) +
    geom_abline(intercept=0, slope=1, linetype="dashed", colour="grey60", linewidth=0.5) +
    geom_ribbon(aes(ymin=lo, ymax=up), alpha=0.12, colour=NA) +
    geom_line(linewidth=1.1) +
    scale_colour_manual(values=c("FeNO"=C_FENO,"BEC"=C_BEC), labels=labs2) +
    scale_fill_manual(values=c("FeNO"=C_FENO,"BEC"=C_BEC), guide="none") +
    ggtitle("Adults") + sroc_theme("A") + title_theme() + auc_legend_theme()
}

## Panel B - FeNO children SROC
panelB <- function() {
  d <- read_excel(F_PED, sheet="BPT_PC20<8"); d$FPR <- 1 - d$Spec; d <- d[order(d$FPR), ]; d$m <- "FeNO"
  lab <- auc_lab("FeNO", F_PED, "BPT_PC20<8")
  ggplot(d, aes(FPR, Sens, colour=m, fill=m)) +
    geom_abline(intercept=0, slope=1, linetype="dashed", colour="grey60", linewidth=0.5) +
    geom_ribbon(aes(ymin=`lower.Sens`, ymax=`upper.Sens`), alpha=0.12, colour=NA) +
    geom_line(linewidth=1.1) +
    scale_colour_manual(values=c("FeNO"=C_FENO), labels=lab) +
    scale_fill_manual(values=c("FeNO"=C_FENO), guide="none") +
    ggtitle("Children") + sroc_theme("B") + title_theme() + auc_legend_theme()
}

## Panel C - FeNO vs FeNO+BEC adults (bivariate Reitsma)
panelC <- function() {
  Data <- read_excel(F_BIVAR, sheet="Master FeNOBEC New", guess=3000)
  conf <- function(combined) {
    Data %>% group_by(STUDY) %>% group_modify(function(.x, .y) {
      d <- na.omit(.x[, c("PC20_8","FENO","BEC")])
      if (length(unique(d$PC20_8)) < 2 || nrow(d) < 8)
        return(tibble(TP=NA_real_, FN=NA_real_, FP=NA_real_, TN=NA_real_))
      score <- if (combined) {
        m <- suppressWarnings(glm(PC20_8 ~ FENO + BEC, data=d, family=binomial)); as.numeric(predict(m, type="response"))
      } else d$FENO
      r   <- suppressMessages(pROC::roc(d$PC20_8, score, quiet=TRUE))
      cut <- as.numeric(pROC::coords(r, "best", best.method="youden", ret="threshold", transpose=FALSE)$threshold)[1]
      tibble(TP=sum(score>=cut & d$PC20_8==1), FN=sum(score<cut & d$PC20_8==1),
             FP=sum(score>=cut & d$PC20_8==0), TN=sum(score<cut & d$PC20_8==0))
    }) %>% ungroup() %>% filter(!is.na(TP) & (TP+FN) > 0 & (TN+FP) > 0)
  }
  mf <- conf(FALSE); mc <- conf(TRUE)
  fit_f <- reitsma(cbind(TP, FN, FP, TN) ~ 1, data=mf)
  fit_c <- reitsma(cbind(TP, FN, FP, TN) ~ 1, data=mc)
  region <- function(fit) {
    grDevices::pdf(NULL); on.exit(grDevices::dev.off())
    e  <- mada::ROCellipse(fit, add=FALSE)
    el <- as.data.frame(e$ROCellipse); names(el)[1:2] <- c("fpr","sens")
    p  <- e$fprsens; if (is.null(dim(p))) p <- matrix(p, nrow=1)
    p  <- as.data.frame(p); names(p)[1:2] <- c("fpr","sens")
    list(ell=el[,1:2], pt=p[,1:2])
  }
  pts <- function(m, lab) data.frame(fpr=m$FP/(m$FP+m$TN), sens=m$TP/(m$TP+m$FN), model=lab)
  L <- "FeNO + BEC"; rf <- region(fit_f); rc <- region(fit_c)
  ell_df <- rbind(cbind(rf$ell, model="FeNO"), cbind(rc$ell, model=L))
  sm_df  <- rbind(cbind(rf$pt,  model="FeNO"), cbind(rc$pt,  model=L))
  pt_df  <- rbind(pts(mf,"FeNO"), pts(mc,L))
  for (df in c("ell_df","sm_df","pt_df")) assign(df, transform(get(df), model=factor(model, c("FeNO", L))))
  pint <- "P-interaction:  Se p=0.94,  Sp p=0.56"
  ggplot() +
    geom_abline(intercept=0, slope=1, linetype="dashed", colour="grey60", linewidth=0.5) +
    geom_point(data=pt_df, aes(fpr, sens, shape=model), colour="grey65", size=1.5, stroke=0.6, show.legend=FALSE) +
    geom_path(data=ell_df, aes(fpr, sens, colour=model), linewidth=0.9) +
    geom_point(data=sm_df, aes(fpr, sens, colour=model, shape=model), size=2.8) +
    scale_colour_manual(values=c("FeNO"=C_FENO, "FeNO + BEC"=C_COMBO)) +
    scale_shape_manual(values=c("FeNO"=16, "FeNO + BEC"=17)) +
    annotate("text", x=0.03, y=0.95, label=pint, hjust=0, vjust=1, size=4, colour="black") +
    ggtitle("Adults") + sroc_theme("C") + title_theme() +
    theme(legend.position=c(0.98,0.10), legend.justification=c(1,0.5), legend.title=element_blank(),
          legend.text=element_text(size=10, colour="black"), legend.key.width=unit(1.5,"lines"),
          legend.key=element_rect(fill=NA, colour=NA), legend.background=element_rect(fill=alpha("white",0.75), colour=NA))
}

## Panel D - DIVE cohort empirical ROC
panelD <- function() {
  D <- read_excel(F_DIVE, sheet=1)
  y    <- ifelse(tolower(trimws(D$pd20pos_200))=="yes", 1, 0)
  feno <- suppressWarnings(as.numeric(D$ea_feno_niox))
  bec  <- suppressWarnings(as.numeric(D$ea_fsc_eos_val))
  d1 <- na.omit(data.frame(y, x=feno)); r1 <- roc(d1$y, d1$x, direction="<", quiet=TRUE)
  d2 <- na.omit(data.frame(y, x=bec));  r2 <- roc(d2$y, d2$x, direction="<", quiet=TRUE)
  cc <- na.omit(data.frame(y, feno, bec))
  m  <- glm(y ~ feno*bec, data=cc, family=binomial)
  r3 <- roc(cc$y, as.numeric(fitted(m)), direction="<", quiet=TRUE)
  lab <- function(name, r) { ci <- as.numeric(ci.auc(r))
    sprintf("%s (AUC = %.2f [%.2f; %.2f])", name, as.numeric(auc(r)), ci[1], ci[3]) }
  mk <- function(r, name) data.frame(FPR=1 - r$specificities, TPR=r$sensitivities, m=name)
  df <- rbind(mk(r1,"FeNO"), mk(r2,"BEC"), mk(r3,"FeNO + BEC"))
  df <- df[order(df$m, df$FPR, df$TPR), ]; df$m <- factor(df$m, levels=c("FeNO","BEC","FeNO + BEC"))
  labs3 <- c(lab("FeNO",r1), lab("BEC",r2), lab("FeNO + BEC",r3))
  ggplot(df, aes(FPR, TPR, colour=m)) +
    geom_abline(intercept=0, slope=1, linetype="dashed", colour="grey60", linewidth=0.5) +
    geom_line(linewidth=1.0) +
    scale_colour_manual(values=c("FeNO"=C_FENO,"BEC"=C_BEC,"FeNO + BEC"=C_COMBO), labels=labs3) +
    ggtitle("Adults (n = 123)") + sroc_theme("D") + title_theme() + auc_legend_theme() +
    theme(legend.position=c(1,0.01), legend.justification=c(1,0), legend.key.width=unit(1.2,"lines"))
}

pA <- panelA(); pB <- panelB()
pC <- tryCatch(panelC(), error=function(e){message("Panel C failed: ",conditionMessage(e)); ggplot()+annotate("text",x=.5,y=.5,label="Panel C failed (see console)",colour="grey50")+theme_void()})
pD <- tryCatch(panelD(), error=function(e){message("Panel D failed: ",conditionMessage(e)); ggplot()+annotate("text",x=.5,y=.5,label="Panel D failed (see console)",colour="grey50")+theme_void()})

section_title <- function(txt, size = 14) wrap_elements(full = grid::textGrob(
  txt, x = 0.5, hjust = 0.5,
  gp = grid::gpar(fontface = "bold", fontsize = size, col = "black")))
divider <- wrap_elements(full = grid::linesGrob(
  x = grid::unit(c(0.02, 0.98), "npc"), y = grid::unit(c(0.5, 0.5), "npc"),
  gp = grid::gpar(col = "grey40", lwd = 1.1)))
hdrMA   <- section_title("Meta-Analysis")
hdrDIVE <- section_title("DIVE cohort")

design <- "MMM\nABC\nLLL\nVVV\n#D#"
fig <- wrap_plots(M = hdrMA, A = pA, B = pB, C = pC, L = divider, V = hdrDIVE, D = pD,
                  design = design, heights = c(0.11, 1, 0.05, 0.11, 1))
ggsave("Figure2_4panel.pdf", fig, width = 12, height = 9.5, device = "pdf", useDingbats = FALSE)
ggsave("Figure2_4panel.png", fig, width = 12, height = 9.5, dpi = 300, bg = "white")
cat("Done -> Figure2_4panel.{pdf,png}\n")
