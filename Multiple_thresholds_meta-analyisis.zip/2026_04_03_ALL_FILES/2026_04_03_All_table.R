
run_full_analysis <- function(file_path, tabs, cutoffs, output_name) {
  
  library(diagmeta)
  library(readxl)
  library(dplyr)
  library(writexl)
  
  # ----------------------------
  # Run diagmeta
  # ----------------------------
  run_analysis <- function(sheet_name) {
    
    data <- read_excel(file_path, sheet = sheet_name) %>%
      mutate(across(c(TP, FN, TN, FP, cutoff), as.numeric)) %>%
      filter(complete.cases(TP, FN, TN, FP, cutoff, studylab))
    
    fit <- diagmeta(
      TP = TP, FP = FP, TN = TN, FN = FN,
      cutoff = cutoff,
      studlab = studylab,
      data = data,
      distr = "logistic",
      log.cutoff = TRUE,
      method.weights = "size"
    )
    
    fit$raw_data <- data
    fit
  }
  
  results <- lapply(tabs, run_analysis)
  names(results) <- tabs
  
  # ----------------------------
  # Summary table
  # ----------------------------
  summary_table <- data.frame(
    Subgroup = names(results),
    k = sapply(results, function(x) x$k),
    Optimal_Cutoff = sapply(results, function(x) x$optcut),
    Cutoff_Lower = sapply(results, function(x) x$lower.optcut),
    Cutoff_Upper = sapply(results, function(x) x$upper.optcut),
    Sens = sapply(results, function(x) x$Sens.optcut),
    Sens_Lower = sapply(results, function(x) x$lower.Sens.optcut),
    Sens_Upper = sapply(results, function(x) x$upper.Sens.optcut),
    Spec = sapply(results, function(x) x$Spec.optcut),
    Spec_Lower = sapply(results, function(x) x$lower.Spec.optcut),
    Spec_Upper = sapply(results, function(x) x$upper.Spec.optcut),
    AUC = sapply(results, function(x) x$AUCSens),
    AUC_Lower = sapply(results, function(x) x$AUCSens.lower),
    AUC_Upper = sapply(results, function(x) x$AUCSens.upper)
  )
  
  # ----------------------------
  # Bootstrap function
  # ----------------------------
  bootstrap_diagstats <- function(model, cutoffs, B = 300,
                                  prevalences = c(0.20, 0.40, 0.56, 0.67)) {
    
    data <- model$raw_data
    n <- nrow(data)
    
    results <- vector("list", B)
    
    for (b in 1:B) {
      
      idx <- sample(1:n, n, replace = TRUE)
      boot_data <- data[idx, , drop = FALSE] %>%
        mutate(
          TP = as.numeric(TP),
          FN = as.numeric(FN),
          TN = as.numeric(TN),
          FP = as.numeric(FP),
          cutoff = as.numeric(cutoff),
          studlab = as.character(studylab)
        )
      
      fit <- tryCatch(
        diagmeta(
          TP = TP, FP = FP, TN = TN, FN = FN,
          cutoff = cutoff,
          studlab = studlab,
          data = boot_data,
          distr = "logistic",
          log.cutoff = TRUE,
          method.weights = "size"
        ),
        error = function(e) NULL
      )
      
      if (is.null(fit)) next
      
      ds <- diagstats(fit, cutoff = cutoffs)
      
      ds$LR_pos <- ds$Sens / (1 - ds$Spec)
      ds$LR_neg <- (1 - ds$Sens) / ds$Spec
      
      for (p in prevalences) {
        suf <- as.character(round(p * 100))
        
        ds[[paste0("PPV_", suf)]] <-
          (ds$Sens * p) / (ds$Sens * p + (1 - ds$Spec) * (1 - p))
        
        ds[[paste0("NPV_", suf)]] <-
          (ds$Spec * (1 - p)) / (ds$Spec * (1 - p) + (1 - ds$Sens) * p)
      }
      
      results[[b]] <- ds
    }
    
    results <- results[!sapply(results, is.null)]
    
    # --- SAFETY CHECK ---
    if (length(results) == 0) {
      warning("All bootstrap iterations failed")
      return(NULL)
    }
    
    combined <- bind_rows(results)
    
    # --- SECOND SAFETY CHECK ---
    if (!"cutoff" %in% colnames(combined)) {
      warning("No cutoff column in bootstrap results")
      return(NULL)
    }
    
    combined %>%
      group_by(cutoff) %>%
      summarise(
        # --- LR CI ---
        LR_pos_lower = quantile(LR_pos, 0.025, na.rm = TRUE),
        LR_pos_upper = quantile(LR_pos, 0.975, na.rm = TRUE),
        LR_neg_lower = quantile(LR_neg, 0.025, na.rm = TRUE),
        LR_neg_upper = quantile(LR_neg, 0.975, na.rm = TRUE)
      )
  }
  
  add_ppv_npv_ci <- function(ds, prev, suffix) {
    
    # --- Point estimates ---
    ds[[paste0("PPV_", suffix)]] <-
      (ds$Sens * prev) / (ds$Sens * prev + (1 - ds$Spec) * (1 - prev))
    
    ds[[paste0("NPV_", suffix)]] <-
      (ds$Spec * (1 - prev)) / (ds$Spec * (1 - prev) + (1 - ds$Sens) * prev)
    
    # --- PPV CI ---
    ds[[paste0("PPV_", suffix, "_lower")]] <-
      (ds$lower.Sens * prev) /
      (ds$lower.Sens * prev + (1 - ds$Spec) * (1 - prev))
    
    ds[[paste0("PPV_", suffix, "_upper")]] <-
      (ds$upper.Sens * prev) /
      (ds$upper.Sens * prev + (1 - ds$Spec) * (1 - prev))
    
    # --- NPV CI ---
    ds[[paste0("NPV_", suffix, "_lower")]] <-
      (ds$lower.Spec * (1 - prev)) /
      (ds$lower.Spec * (1 - prev) + (1 - ds$Sens) * prev)
    
    ds[[paste0("NPV_", suffix, "_upper")]] <-
      (ds$upper.Spec * (1 - prev)) /
      (ds$upper.Spec * (1 - prev) + (1 - ds$Sens) * prev)
    
    ds
  }
  
  # ----------------------------
  # Build tables
  # ----------------------------
  stats_list <- lapply(results, function(x) {
    
    df <- diagstats(x, cutoff = cutoffs)
    
    # --- LR (keep as is) ---
    df <- df %>%
      mutate(
        LR_pos = Sens / (1 - Spec),
        LR_neg = (1 - Sens) / Spec
      )
    
    # --- Add PPV/NPV + CI ---
    df <- add_ppv_npv_ci(df, 0.20, "20")
    df <- add_ppv_npv_ci(df, 0.40, "40")
    df <- add_ppv_npv_ci(df, 0.56, "56")
    df <- add_ppv_npv_ci(df, 0.67, "67")
    
    boot_ci <- bootstrap_diagstats(x, cutoffs, B = 500)
    
    if (is.null(boot_ci)) {
      df   
    } else {
      left_join(df, boot_ci, by = "cutoff")
    }
  })
  
  names(stats_list) <- names(results)
  
  # ----------------------------
  # Export
  # ----------------------------
  all_sheets <- c(list(Summary = summary_table), stats_list)
  
  write_xlsx(all_sheets, output_name)
}

run_full_analysis(
  file_path = "MasterDataMTM.xlsx",
  tabs = c("BPT_PC20<8", "BPT_PC20<8_N", "Only_Hista", "Only_Meta",
           "Only_Indirect", "Prospect", "Retro", "Meta_PC20<4", "Meta_PC20<8",
           "Meta_PC20<16", "Primary_Care", "MTM_All", "MTM_All_N"),
  cutoffs = 1:100,
  output_name = "diagmeta_results_adult.xlsx"
)

run_full_analysis(
  file_path = "MasterDataMTM PED.xlsm",
  tabs = c("BPT_PC20<8", "BPT_PC20<8_AN", "Only_EIB", "Only_Meta",
           "Atopic", "Prospect", "Retro", "MTM_All"),
  cutoffs = 1:100,
  output_name = "diagmeta_results_PED.xlsx"
)

run_full_analysis(
  file_path = "MasterDataMTM_BEC.xlsx",
  tabs = c("PC20<4","PC20<8","PC20<16"),
  cutoffs = seq(10, 1000, by = 10),
  output_name = "diagmeta_results_BEC.xlsx"
)
