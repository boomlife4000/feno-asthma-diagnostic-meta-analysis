# Manuscript figures

Self-contained R scripts that rebuild the manuscript's composite figures from the
analysis outputs. One subfolder per figure; each is runnable on its own.

## Figure 2 — composite summary ROC (`Figure2_composite_SROC/`)

Four ROC panels:

- **A** — FeNO + BEC, adults (POOL meta-analysis, multiple-threshold model)
- **B** — FeNO, children (POOL meta-analysis, multiple-threshold model)
- **C** — FeNO vs FeNO + BEC, adults (POOL meta-analysis, bivariate model)
- **D** — FeNO / BEC / FeNO + BEC, DIVE prospective validation cohort (n = 123 adults, NCT05592519)

Panels A–C are the meta-analysis; panel D is the external validation cohort (set apart by the divider).

Inputs (same folder as the script):

| File | Source analysis |
|------|-----------------|
| `diagmeta_results_adult.xlsx`, `diagmeta_results_PED.xlsx`, `diagmeta_results_BEC.xlsx` | multiple-thresholds meta-analysis (`Multiple_thresholds_meta-analyisis.zip`) |
| `MasterDataV2.xlsx` | bivariate model (`Bivariate_Meta_and_Funnel_ALL_FILES.zip`) |
| `DIVE_Analysis.xlsx` | anonymised DIVE cohort (`DIVE_anonymised.zip`) |

Run:

```r
setwd("Figure2_composite_SROC")
source("Figure2_composite_SROC.R")
```

Outputs: `Figure2_4panel.pdf` (vector) and `Figure2_4panel.png` (300 dpi).

Packages: `readxl`, `ggplot2`, `dplyr`, `patchwork`, `grid`, `mada`, `pROC`.
