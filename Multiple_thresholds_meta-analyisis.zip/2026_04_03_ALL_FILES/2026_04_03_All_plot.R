
###############################
## MASTERDATA ANALYSIS 
###############################
library(diagmeta)
library(readxl)
library(dplyr)
library(ggplot2)
library(writexl)

###############################
## ADULT
###############################

file_path <- "MasterDataMTM.xlsx"

tabs <- c("BPT_PC20<8", "BPT_PC20<8_N", "Only_Hista", "Only_Meta",
          "Only_Indirect", "Prospect", "Retro", "Meta_PC20<4", "Meta_PC20<8",
          "Meta_PC20<16", "Primary_Care", "MTM_All", "MTM_All_N")

run_analysis <- function(sheet_name, file = file_path) {
  
  data <- read_excel(file, sheet = sheet_name) %>%
    mutate(across(c(TP, FN, TN, FP, cutoff), as.numeric)) %>%
    filter(complete.cases(TP, FN, TN, FP, cutoff, studylab))
  
  fit <- diagmeta(
    TP = TP, FP = FP, TN = TN, FN = FN,
    cutoff = cutoff,
    studlab = studylab,
    data = data,
    distr = "logistic",
    log.cutoff = TRUE,
    method.weights = "size"
  )
  
  fit$raw_data <- data
  return(fit)
}

resultsfenoadult <- lapply(tabs, run_analysis)
names(resultsfenoadult) <- tabs

###############################
## PED
###############################

file_path <- "MasterDataMTM PED.xlsm"

tabs <- c("BPT_PC20<8", "BPT_PC20<8_AN", "Only_EIB", "Only_Meta", 
          "Atopic", "Prospect", "Retro", "MTM_All")

run_analysis <- function(sheet_name, file = file_path) {
  
  data <- read_excel(file, sheet = sheet_name) %>%
    mutate(across(c(TP, FN, TN, FP, cutoff), as.numeric)) %>%
    filter(complete.cases(TP, FN, TN, FP, cutoff, studylab))
  
  fit <- diagmeta(
    TP = TP, FP = FP, TN = TN, FN = FN,
    cutoff = cutoff,
    studlab = studylab,
    data = data,
    distr = "logistic",
    log.cutoff = TRUE,
    method.weights = "size"
  )
  
  fit$raw_data <- data
  return(fit)
}

resultsfenoped <- lapply(tabs, run_analysis)
names(resultsfenoped) <- tabs

###############################
## ADULT - BEC
###############################

file_path <- "MasterDataMTM_BEC.xlsx"

tabs <- c("PC20<4","PC20<8","PC20<16")

run_analysis <- function(sheet_name, file = file_path) {
  
  data <- read_excel(file, sheet = sheet_name) %>%
    mutate(across(c(TP, FN, TN, FP, cutoff), as.numeric)) %>%
    filter(complete.cases(TP, FN, TN, FP, cutoff, studylab))
  
  fit <- diagmeta(
    TP = TP, FP = FP, TN = TN, FN = FN,
    cutoff = cutoff,
    studlab = studylab,
    data = data,
    distr = "logistic",
    log.cutoff = TRUE,
    method.weights = "size"
  )
  
  fit$raw_data <- data
  return(fit)
}

resultsbecadult <- lapply(tabs, run_analysis)
names(resultsbecadult) <- tabs

###############################
## SROC PLOT FUNCTION
##############################
plot_sroc_auto <- function(model, cutoffs = 1:300, highlight_cutoff = 55, test_name = "FeNO") {
  
  ds <- diagstats(model, cutoff = cutoffs)
  ds$FPR <- 1 - ds$Spec
  
  opt <- ds[ds$cutoff == highlight_cutoff, ]
  lr_plus <- opt$Sens / (1 - opt$Spec)
  
  auc_val <- round(model$AUCSens, 3)
  auc_lower <- round(model$AUCSens.lower, 3)
  auc_upper <- round(model$AUCSens.upper, 3)
  
  threshold_label <- paste0(test_name, " \u2265 ", highlight_cutoff, " ppb")
  lr_label <- paste0("LR+ = ", round(lr_plus, 2))
  auc_label <- paste0("AUC = ", auc_val, " [", auc_lower, "\u2013", auc_upper, "]")
  
  ggplot(ds, aes(x = FPR, y = Sens)) +
    geom_hline(yintercept = seq(0.25, 0.75, 0.25), color = "grey92", linewidth = 0.3) +
    geom_vline(xintercept = seq(0.25, 0.75, 0.25), color = "grey92", linewidth = 0.3) +
    geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "grey60", linewidth = 0.5) +
    geom_line(aes(y = upper.Sens), color = "grey50", linewidth = 0.6, alpha = 0.8) +
    geom_line(aes(y = lower.Sens), color = "grey50", linewidth = 0.6, alpha = 0.8) +
    geom_line(color = "black", linewidth = 1.2) +
    geom_point(data = opt, aes(x = FPR, y = Sens), 
               color = "#D62728", fill = "white", size = 3.5, shape = 21, stroke = 1.8) +
    annotate("label", 
             x = opt$FPR + 0.06, 
             y = opt$Sens + 0.08,
             label = threshold_label,
             size = 3.3, 
             fontface = "bold",
             fill = "white",
             label.size = 0,
             label.padding = unit(0.2, "lines")) +
    annotate("text", 
             x = opt$FPR + 0.06, 
             y = opt$Sens + 0.02,
             label = lr_label,
             size = 3, 
             hjust = 0,
             color = "grey30") +
    annotate("segment",
             x = opt$FPR + 0.008, xend = opt$FPR + 0.05,
             y = opt$Sens + 0.008, yend = opt$Sens + 0.06,
             color = "grey50", linewidth = 0.4) +
    annotate("text", 
             x = 0.97, y = 0.03,
             label = auc_label,
             size = 3.5, 
             hjust = 1,
             fontface = "italic",
             color = "grey25") +
    scale_x_continuous(
      limits = c(0, 1), 
      expand = c(0.01, 0.01),
      breaks = seq(0, 1, 0.25), 
      minor_breaks = seq(0, 1, 0.05)
    ) +
    scale_y_continuous(
      limits = c(0, 1), 
      expand = c(0.01, 0.01),
      breaks = seq(0, 1, 0.25), 
      minor_breaks = seq(0, 1, 0.05)
    ) +
    labs(x = "1 \u2212 Specificity", y = "Sensitivity") +
    theme_classic(base_size = 12) +
    theme(
      aspect.ratio = 1,
      axis.title = element_text(size = 12, face = "bold", color = "grey20"),
      axis.text = element_text(size = 10, color = "grey30"),
      axis.ticks = element_line(color = "grey50", linewidth = 0.4),
      axis.ticks.length = unit(0.15, "cm"),
      axis.minor.ticks.length = rel(0.5),
      axis.line = element_line(color = "grey30", linewidth = 0.5),
      plot.margin = margin(10, 15, 10, 10)
    ) +
    guides(
      x = guide_axis(minor.ticks = TRUE), 
      y = guide_axis(minor.ticks = TRUE)
    )
}

###############################
## PPV BY PREVALENCE PLOT FUNCTION
##############################
plot_ppv_by_prevalence <- function(model, cutoffs = 1:100, 
                                   prevalences = c(0.20, 0.33, 0.50),
                                   prevalence_labels = c("Lower prevalence (20%)", "Medium prevalence (33%)", "High prevalence (50%)"),
                                   test_name = "FeNO",
                                   highlight_cutoff = NULL) {
  
  ds <- diagstats(model, cutoff = cutoffs)
  
  ppv_data <- lapply(prevalences, function(prev) {
    data.frame(
      cutoff = ds$cutoff,
      prevalence = prev,
      PPV = (ds$Sens * prev) / (ds$Sens * prev + (1 - ds$Spec) * (1 - prev)),
      Sens = ds$Sens,
      Spec = ds$Spec
    )
  }) %>% bind_rows()
  
  ppv_data$prev_label <- factor(ppv_data$prevalence, 
                                levels = prevalences, 
                                labels = prevalence_labels)
  
  p <- ggplot(ppv_data, aes(x = cutoff, y = PPV, color = prev_label)) +
    geom_hline(yintercept = seq(0.2, 0.8, 0.2), color = "grey92", linewidth = 0.3) +
    geom_vline(xintercept = seq(20, 80, 20), color = "grey92", linewidth = 0.3) +
    geom_line(linewidth = 1.1) +
    scale_color_manual(values = c("#D55E00", "#0072B2", "#009E73")) +
    scale_y_continuous(
      limits = c(0, 1), 
      expand = c(0.01, 0.01),
      breaks = seq(0, 1, 0.2),
      minor_breaks = seq(0, 1, 0.05),
      labels = scales::percent_format()
    ) +
    scale_x_continuous(
      limits = c(0, 100),
      expand = c(0.01, 0.01),
      breaks = seq(0, 100, 20),
      minor_breaks = seq(0, 100, 5)
    ) +
    labs(
      x = paste0(test_name, " threshold (ppb)"),
      y = "Positive Predictive Value",
      color = NULL
    ) +
    theme_classic(base_size = 12) +
    theme(
      axis.title = element_text(size = 12, face = "bold", color = "grey20"),
      axis.text = element_text(size = 10, color = "grey30"),
      axis.ticks = element_line(color = "grey50", linewidth = 0.4),
      axis.ticks.length = unit(0.15, "cm"),
      axis.minor.ticks.length = rel(0.5),
      axis.line = element_line(color = "grey30", linewidth = 0.5),
      legend.position = c(0.55, 0.0725),
      legend.direction = "horizontal",
      legend.background = element_rect(fill = alpha("white", 0.9), color = NA),
      legend.key.width = unit(0.8, "cm"),
      legend.text = element_text(size = 8, color = "grey25"),
      plot.margin = margin(10, 15, 10, 10)
    ) +
    guides(
      x = guide_axis(minor.ticks = TRUE),
      y = guide_axis(minor.ticks = TRUE),
      color = guide_legend(nrow = 1)
    )
  
  if (!is.null(highlight_cutoff)) {
    highlight_data <- ppv_data[ppv_data$cutoff == highlight_cutoff, ]
    
    p <- p +
      geom_vline(xintercept = highlight_cutoff, linetype = "dashed", color = "grey60", linewidth = 0.5) +
      geom_point(data = highlight_data, aes(x = cutoff, y = PPV, fill = prev_label), 
                 size = 3.5, shape = 21, stroke = 1.2, color = "white") +
      scale_fill_manual(values = c("#D55E00", "#0072B2", "#009E73"), guide = "none") +
      annotate("label", 
               x = highlight_cutoff, 
               y = 0.98,
               label = paste0(test_name, " \u2265 ", highlight_cutoff, " ppb"),
               size = 3.3, 
               fontface = "bold",
               fill = "white",
               label.size = 0,
               label.padding = unit(0.2, "lines"),
               color = "grey25")
  }
  
  return(p)
}


###############################
## SROC PLOT FUNCTION - BEC
##############################
plot_sroc_auto_bec <- function(model, cutoffs = seq(10, 1000, by = 10), highlight_cutoff = 300, test_name = "BEC") {
  
  ds <- diagstats(model, cutoff = cutoffs)
  ds$FPR <- 1 - ds$Spec
  
  opt <- ds[ds$cutoff == highlight_cutoff, ]
  lr_plus <- opt$Sens / (1 - opt$Spec)
  
  auc_val <- round(model$AUCSens, 3)
  auc_lower <- round(model$AUCSens.lower, 3)
  auc_upper <- round(model$AUCSens.upper, 3)
  
  threshold_label <- paste0(test_name, " \u2265 ", highlight_cutoff, " ppb")
  lr_label <- paste0("LR+ = ", round(lr_plus, 2))
  auc_label <- paste0("AUC = ", auc_val, " [", auc_lower, "\u2013", auc_upper, "]")
  
  ggplot(ds, aes(x = FPR, y = Sens)) +
    geom_hline(yintercept = seq(0.25, 0.75, 0.25), color = "grey92", linewidth = 0.3) +
    geom_vline(xintercept = seq(0.25, 0.75, 0.25), color = "grey92", linewidth = 0.3) +
    geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "grey60", linewidth = 0.5) +
    geom_line(aes(y = upper.Sens), color = "grey50", linewidth = 0.6, alpha = 0.8) +
    geom_line(aes(y = lower.Sens), color = "grey50", linewidth = 0.6, alpha = 0.8) +
    geom_line(color = "black", linewidth = 1.2) +
    geom_point(data = opt, aes(x = FPR, y = Sens), 
               color = "#D62728", fill = "white", size = 3.5, shape = 21, stroke = 1.8) +
    annotate("label", 
             x = opt$FPR + 0.06, 
             y = opt$Sens + 0.08,
             label = threshold_label,
             size = 3.3, 
             fontface = "bold",
             fill = "white",
             label.size = 0,
             label.padding = unit(0.2, "lines")) +
    annotate("text", 
             x = opt$FPR + 0.06, 
             y = opt$Sens + 0.02,
             label = lr_label,
             size = 3, 
             hjust = 0,
             color = "grey30") +
    annotate("segment",
             x = opt$FPR + 0.008, xend = opt$FPR + 0.05,
             y = opt$Sens + 0.008, yend = opt$Sens + 0.06,
             color = "grey50", linewidth = 0.4) +
    annotate("text", 
             x = 0.97, y = 0.03,
             label = auc_label,
             size = 3.5, 
             hjust = 1,
             fontface = "italic",
             color = "grey25") +
    scale_x_continuous(
      limits = c(0, 1), 
      expand = c(0.01, 0.01),
      breaks = seq(0, 1, 0.25), 
      minor_breaks = seq(0, 1, 0.05)
    ) +
    scale_y_continuous(
      limits = c(0, 1), 
      expand = c(0.01, 0.01),
      breaks = seq(0, 1, 0.25), 
      minor_breaks = seq(0, 1, 0.05)
    ) +
    labs(x = "1 \u2212 Specificity", y = "Sensitivity") +
    theme_classic(base_size = 12) +
    theme(
      aspect.ratio = 1,
      axis.title = element_text(size = 12, face = "bold", color = "grey20"),
      axis.text = element_text(size = 10, color = "grey30"),
      axis.ticks = element_line(color = "grey50", linewidth = 0.4),
      axis.ticks.length = unit(0.15, "cm"),
      axis.minor.ticks.length = rel(0.5),
      axis.line = element_line(color = "grey30", linewidth = 0.5),
      plot.margin = margin(10, 15, 10, 10)
    ) +
    guides(
      x = guide_axis(minor.ticks = TRUE), 
      y = guide_axis(minor.ticks = TRUE)
    )
}

###############################
## PPV BY PREVALENCE PLOT FUNCTION - BEC
##############################

plot_ppv_by_prevalence_bec <- function(model, cutoffs = seq(10, 1000, by = 10), 
                                   prevalences = c(0.20, 0.33, 0.50),
                                   prevalence_labels = c("Lower prevalence (20%)", "Medium prevalence (33%)", "High prevalence (50%)"),
                                   test_name = "BEC",
                                   highlight_cutoff = NULL) {
  
  ds <- diagstats(model, cutoff = cutoffs)
  
  ppv_data <- lapply(prevalences, function(prev) {
    data.frame(
      cutoff = ds$cutoff,
      prevalence = prev,
      PPV = (ds$Sens * prev) / (ds$Sens * prev + (1 - ds$Spec) * (1 - prev)),
      Sens = ds$Sens,
      Spec = ds$Spec
    )
  }) %>% bind_rows()
  
  ppv_data$prev_label <- factor(ppv_data$prevalence, 
                                levels = prevalences, 
                                labels = prevalence_labels)
  
  p <- ggplot(ppv_data, aes(x = cutoff, y = PPV, color = prev_label)) +
    geom_hline(yintercept = seq(0.2, 0.8, 0.2), color = "grey92", linewidth = 0.3) +
    geom_vline(xintercept = seq(200, 800, 200), color = "grey92", linewidth = 0.3) +
    geom_line(linewidth = 1.1) +
    scale_color_manual(values = c("#D55E00", "#0072B2", "#009E73")) +
    scale_y_continuous(
      limits = c(0, 1), 
      expand = c(0.01, 0.01),
      breaks = seq(0, 1, 0.2),
      minor_breaks = seq(0, 1, 0.05),
      labels = scales::percent_format()
    ) +
    scale_x_continuous(
      limits = c(0, 1000),
      expand = c(0.01, 0.01),
      breaks = seq(0, 1000, 200),
      minor_breaks = seq(0, 1000, 50)
    ) +
    labs(
      x = paste0(test_name, " threshold (cells/\u00B5L)"),
      y = "Positive Predictive Value",
      color = NULL
    ) +
    theme_classic(base_size = 12) +
    theme(
      axis.title = element_text(size = 12, face = "bold", color = "grey20"),
      axis.text = element_text(size = 10, color = "grey30"),
      axis.ticks = element_line(color = "grey50", linewidth = 0.4),
      axis.ticks.length = unit(0.15, "cm"),
      axis.minor.ticks.length = rel(0.5),
      axis.line = element_line(color = "grey30", linewidth = 0.5),
      legend.position = c(0.55, 0.0725),
      legend.direction = "horizontal",
      legend.background = element_rect(fill = alpha("white", 0.9), color = NA),
      legend.key.width = unit(0.8, "cm"),
      legend.text = element_text(size = 8, color = "grey25"),
      plot.margin = margin(10, 15, 10, 10)
    ) +
    guides(
      x = guide_axis(minor.ticks = TRUE),
      y = guide_axis(minor.ticks = TRUE),
      color = guide_legend(nrow = 1)
    )
  
  if (!is.null(highlight_cutoff)) {
    highlight_data <- ppv_data[ppv_data$cutoff == highlight_cutoff, ]
    
    p <- p +
      geom_vline(xintercept = highlight_cutoff, linetype = "dashed", color = "grey60", linewidth = 0.5) +
      geom_point(data = highlight_data, aes(x = cutoff, y = PPV, fill = prev_label), 
                 size = 3.5, shape = 21, stroke = 1.2, color = "white") +
      scale_fill_manual(values = c("#D55E00", "#0072B2", "#009E73"), guide = "none") +
      annotate("label", 
               x = highlight_cutoff, 
               y = 0.98,
               label = paste0(test_name, " \u2265 ", highlight_cutoff, " cells/\u00B5L"),
               size = 3.3, 
               fontface = "bold",
               fill = "white",
               label.size = 0,
               label.padding = unit(0.2, "lines"),
               color = "grey25")
  }
  
  return(p)
}

###############################
## USAGE EXAMPLES
##############################

# SROC plot
plot_sroc_auto(resultsfenoadult$`BPT_PC20<8`, highlight_cutoff = 55)
ggsave("ROC_FeNO_final.png", width = 5, height = 5, dpi = 600, bg = "white")

# SROC plot
plot_sroc_auto(resultsfenoped$`BPT_PC20<8`)
ggsave("ROC_FeNO_final_PED.png", width = 5, height = 5, dpi = 600, bg = "white")

# PPV by prevalence plot
plot_ppv_by_prevalence(resultsfenoped$`BPT_PC20<8`, cutoffs = 1:100, highlight_cutoff = NULL)
ggsave("PPV_by_prevalence_PED.png", width = 7, height = 5, dpi = 600, bg = "white")

# SROC plot
plot_sroc_auto_bec(resultsbecadult$`PC20<8`)
ggsave("ROC_FeNO_final_BEC.png", width = 5, height = 5, dpi = 600, bg = "white")

# PPV by prevalence plot
plot_ppv_by_prevalence_bec(resultsbecadult$`PC20<8`, cutoffs = seq(10, 1000, by = 10), highlight_cutoff = NULL)
ggsave("PPV_by_prevalence_BEC.png", width = 7, height = 5, dpi = 600, bg = "white")



# ============================================================
# PPV PANEL PLOT WITH CI RIBBON (updated from V2.R)
# ============================================================

plot_ppv_panel_ci <- function(model, cutoffs,
                              prevalences = c(0.20, 0.40, 0.56, 0.67),
                              prevalence_labels = c("20%", "40%", "56%", "67%"),
                              test_name = "FeNO",
                              unit_label = "ppb",
                              x_label = "FeNO threshold (ppb)",
                              panel_label = NULL) {
  
  ds <- diagstats(model, cutoff = cutoffs)
  
  ppv_data <- lapply(seq_along(prevalences), function(i) {
    prev <- prevalences[i]
    data.frame(
      cutoff     = ds$cutoff,
      prevalence = prev,
      label      = prevalence_labels[i],
      PPV        = (ds$Sens * prev) /
        (ds$Sens * prev + (1 - ds$Spec) * (1 - prev)),
      PPV_lower  = (ds$lower.Sens * prev) /
        (ds$lower.Sens * prev + (1 - ds$Spec) * (1 - prev)),
      PPV_upper  = (ds$upper.Sens * prev) /
        (ds$upper.Sens * prev + (1 - ds$Spec) * (1 - prev))
    )
  }) %>% bind_rows()
  
  ppv_data$label <- factor(ppv_data$label, levels = prevalence_labels)
  
  colors <- c("20%" = "#D55E00",
              "40%" = "#0072B2",
              "56%" = "#009E73",
              "67%" = "#7B2D8E")
  
  # --- Crossing points at PPV = 80% ---
  crossing_data <- lapply(seq_along(prevalences), function(i) {
    
    prev <- prevalences[i]
    
    sub <- ppv_data[ppv_data$prevalence == prev, ]
    
    hits <- sub[sub$PPV >= 0.80, ]
    
    if (nrow(hits) == 0) return(NULL)
    
    first_hit <- hits[which.min(hits$cutoff), ]
    
    first_hit$cross_label <- paste0("\u2265 ", first_hit$cutoff)
    
    first_hit
    
  }) %>% bind_rows()
  
  p <- ggplot(ppv_data,
              aes(x = cutoff, y = PPV,
                  color = label, fill = label)) +
    
    geom_hline(yintercept = seq(0.2, 0.8, 0.2),
               color = "grey92", linewidth = 0.3) +
    
    geom_hline(yintercept = 0.80,
               linetype = "dotted",
               color = "grey50",
               linewidth = 0.5) +
    
    geom_ribbon(aes(ymin = PPV_lower, ymax = PPV_upper),
                alpha = 0.15,
                colour = NA) +
    
    geom_line(linewidth = 1.0) +
    
    scale_color_manual(values = colors) +
    scale_fill_manual(values = colors) +
    
    scale_y_continuous(
      limits = c(0,1.1),
      expand = c(0.01,0.01),
      breaks = seq(0,1,0.2),
      labels = scales::percent_format()
    ) +
    
    scale_x_continuous(expand = c(0.01,0.01)) +
    
    labs(
      x = x_label,
      y = "Positive predictive value",
      color = "Prevalence",
      fill  = "Prevalence"
    ) +
    
    theme_classic(base_size = 11) +
    
    theme(
      axis.title = element_text(size = 10, face = "bold", color = "grey20"),
      axis.text  = element_text(size = 9, color = "grey30"),
      axis.ticks = element_line(color = "grey50", linewidth = 0.4),
      axis.line  = element_line(color = "grey30", linewidth = 0.5),
      legend.position = "bottom",
      legend.direction = "horizontal",
      legend.background = element_rect(fill = alpha("white",0.9), color = NA),
      legend.key.width = unit(1,"cm"),
      legend.text = element_text(size = 8.5, color = "grey25"),
      legend.title = element_text(size = 9, face = "bold", color = "grey25"),
      plot.margin = margin(10,10,5,10)
    ) +
    
    guides(
      x = guide_axis(minor.ticks = TRUE),
      y = guide_axis(minor.ticks = TRUE),
      color = guide_legend(nrow = 1),
      fill  = guide_legend(nrow = 1)
    )
  
  # --- Add panel label (A, B, C...) top-left ---
  if (!is.null(panel_label)) {
    
    p <- p +
      annotate(
        "text",
        x = -Inf,
        y = 1,
        label = panel_label,
        hjust = -0.3,
        vjust = 0,
        size = 5,
        fontface = "bold"
      )
  }
  
  # --- Crossing dots + labels ---
  if (nrow(crossing_data) > 0) {
    
    p <- p +
      geom_point(data = crossing_data,
                 aes(x = cutoff, y = PPV),
                 size = 2,
                 show.legend = FALSE)
    
    for (i in seq_len(nrow(crossing_data))) {
      
      row <- crossing_data[i, ]
      
      p <- p +
        annotate(
          "text",
          x = row$cutoff,
          y = row$PPV + 0.04,
          label = row$cross_label,
          size = 2.5,
          fontface = "bold",
          color = colors[row$label]
        )
    }
  }
  
  return(p)
}

# ============================================================
# NPV PANEL PLOT WITH CI RIBBON (updated from V3_NPV.R)
# ============================================================

plot_npv_panel_ci <- function(model, cutoffs,
                              prevalences = c(0.20, 0.40, 0.56, 0.67),
                              prevalence_labels = c("20%", "40%", "56%", "67%"),
                              test_name = "FeNO",
                              unit_label = "ppb",
                              x_label = "FeNO threshold (ppb)",
                              panel_label = NULL) {
  
  ds <- diagstats(model, cutoff = cutoffs)
  
  npv_data <- lapply(seq_along(prevalences), function(i) {
    
    prev <- prevalences[i]
    
    data.frame(
      cutoff     = ds$cutoff,
      prevalence = prev,
      label      = prevalence_labels[i],
      
      NPV = (ds$Spec * (1 - prev)) /
        (ds$Spec * (1 - prev) + (1 - ds$Sens) * prev),
      
      NPV_lower = (ds$lower.Spec * (1 - prev)) /
        (ds$lower.Spec * (1 - prev) + (1 - ds$Sens) * prev),
      
      NPV_upper = (ds$upper.Spec * (1 - prev)) /
        (ds$upper.Spec * (1 - prev) + (1 - ds$Sens) * prev)
    )
    
  }) %>% bind_rows()
  
  npv_data$label <- factor(npv_data$label, levels = prevalence_labels)
  
  colors <- c(
    "20%" = "#D55E00",
    "40%" = "#0072B2",
    "56%" = "#009E73",
    "67%" = "#7B2D8E"
  )
  
  # --- Crossing points at NPV = 90% ---
  crossing_data <- lapply(seq_along(prevalences), function(i) {
    
    prev <- prevalences[i]
    
    sub <- npv_data[npv_data$prevalence == prev, ]
    
    hits <- sub[sub$NPV >= 0.90, ]
    
    if (nrow(hits) == 0) return(NULL)
    
    last_hit <- hits[which.max(hits$cutoff), ]
    
    last_hit$cross_label <- paste0("\u2264 ", last_hit$cutoff)
    
    last_hit
    
  }) %>% bind_rows()
  
  
  p <- ggplot(npv_data,
              aes(x = cutoff,
                  y = NPV,
                  color = label,
                  fill = label)) +
    
    geom_hline(yintercept = seq(0.2, 0.8, 0.2),
               color = "grey92",
               linewidth = 0.3) +
    
    geom_hline(yintercept = 0.90,
               linetype = "dotted",
               color = "grey50",
               linewidth = 0.5) +
    
    geom_ribbon(aes(ymin = NPV_lower,
                    ymax = NPV_upper),
                alpha = 0.15,
                colour = NA) +
    
    geom_line(linewidth = 1.0) +
    
    scale_color_manual(values = colors) +
    scale_fill_manual(values = colors) +
    
    scale_y_continuous(
      limits = c(0,1.1),
      expand = c(0.01,0.01),
      breaks = seq(0,1,0.2),
      labels = scales::percent_format()
    ) +
    
    scale_x_continuous(expand = c(0.01,0.01)) +
    
    labs(
      x = x_label,
      y = "Negative predictive value",
      color = "Prevalence",
      fill  = "Prevalence"
    ) +
    
    theme_classic(base_size = 11) +
    
    theme(
      axis.title = element_text(size = 10, face = "bold", color = "grey20"),
      axis.text  = element_text(size = 9, color = "grey30"),
      axis.ticks = element_line(color = "grey50", linewidth = 0.4),
      axis.line  = element_line(color = "grey30", linewidth = 0.5),
      
      legend.position = "bottom",
      legend.direction = "horizontal",
      
      legend.background = element_rect(fill = alpha("white",0.9), color = NA),
      legend.key.width = unit(1,"cm"),
      legend.text = element_text(size = 8.5, color = "grey25"),
      legend.title = element_text(size = 9, face = "bold", color = "grey25"),
      
      plot.margin = margin(10,10,5,10)
    ) +
    
    guides(
      x = guide_axis(minor.ticks = TRUE),
      y = guide_axis(minor.ticks = TRUE),
      color = guide_legend(nrow = 1),
      fill  = guide_legend(nrow = 1)
    )
  
  
  # --- Add panel label (A–F) top-left ---
  if (!is.null(panel_label)) {
    
    p <- p +
      annotate(
        "text",
        x = -Inf,
        y = Inf,
        label = panel_label,
        hjust = -0.3,
        vjust = 1.4,
        size = 5,
        fontface = "bold"
      )
  }
  
  
  # --- Crossing dots + labels ---
  if (nrow(crossing_data) > 0) {
    
    p <- p +
      geom_point(data = crossing_data,
                 aes(x = cutoff, y = NPV),
                 size = 2,
                 show.legend = FALSE)
    
    for (i in seq_len(nrow(crossing_data))) {
      
      row <- crossing_data[i, ]
      
      p <- p +
        annotate(
          "text",
          x = row$cutoff,
          y = row$NPV - 0.04,
          label = row$cross_label,
          size = 2.5,
          fontface = "bold",
          color = colors[row$label]
        )
    }
  }
  
  return(p)
}


library(patchwork)

# ---- PPV panels ----
ppv_A <- plot_ppv_panel_ci(
  model       = resultsfenoadult$`BPT_PC20<8`,
  cutoffs     = 1:100,
  x_label     = "FeNO in adults threshold (ppb)",
  panel_label = "A."
)

ppv_C <- plot_ppv_panel_ci(
  model       = resultsfenoped$`BPT_PC20<8`,
  cutoffs     = 1:100,
  x_label     = "FeNO threshold (ppb)",
  panel_label = "B."
)

ppv_E <- plot_ppv_panel_ci(
  model       = resultsbecadult$`PC20<8`,
  cutoffs     = seq(10, 1000, by = 10),
  test_name   = "BEC",
  unit_label  = "cells/\u00B5L",
  x_label     = expression(bold(paste("BEC threshold (cells/", mu, "L)"))),
  panel_label = "C."
)

# ---- NPV panels ----
npv_B <- plot_npv_panel_ci(
  model       = resultsfenoadult$`BPT_PC20<8`,
  cutoffs     = 1:100,
  x_label     = "\nFeNO threshold in adults (ppb)",
  panel_label = "D."
)

npv_D <- plot_npv_panel_ci(
  model       = resultsfenoped$`BPT_PC20<8`,
  cutoffs     = 1:100,
  x_label     = "\nFeNO threshold in children (ppb)",
  panel_label = "E."
)

npv_F <- plot_npv_panel_ci(
  model       = resultsbecadult$`PC20<8`,
  cutoffs     = seq(10, 1000, by = 10),
  test_name   = "BEC",
  unit_label  = "cells/\u00B5L",
  x_label = expression(atop("", bold(paste("BEC threshold in adults (cells/", mu, "L)")))),
  panel_label = "F."
)


# Remove Y axis from columns 2 and 3
remove_y <- theme(
  axis.title.y = element_blank(),
  axis.text.y  = element_blank(),
  axis.ticks.y = element_blank()
)

# Remove X axis from top row
remove_x <- theme(
  axis.title.x = element_blank(),
  axis.text.x  = element_blank(),
  axis.ticks.x = element_blank()
)


ppv_row <- (
  ppv_A + remove_x |
    (ppv_C + remove_x + remove_y) |
    (ppv_E + remove_x + remove_y)
)


npv_row <- (
  npv_B |
    (npv_D + remove_y) |
    (npv_F + remove_y)
)

final_figure <- (
  ppv_row /
    npv_row
) +
  plot_layout(guides = "collect") &
  theme(legend.position = "bottom")

ggsave("figure_ppv_npv.png",final_figure, width = 14, height = 8, dpi = 600)

